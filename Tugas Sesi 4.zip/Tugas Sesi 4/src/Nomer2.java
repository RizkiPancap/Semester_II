public class Nomer2 {
  public static void main(String[] args) throws Exception {
    for (int i = 0; i < 2; i++) {
      System.out.println("* ");
  }
  
  }
}
