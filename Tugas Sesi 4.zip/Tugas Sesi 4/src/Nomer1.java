public class Nomer1 {
    public static void main(String[] args) throws Exception {
        for (int i = 2; i <= 10; i++) {
            System.out.print(i+ " ");
            i++;
        }
    }
}
